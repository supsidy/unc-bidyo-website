import { useState, useEffect, useRef, useCallback } from "react";

const AUTOPLAY_DELAY = 5000; // ms between auto-advances — 5-7s recommended for promotional content
const TRANSITION_MS = 750;
const SWIPE_THRESHOLD_PX = 50; // minimum drag distance to count as an intentional swipe

export default function OfferCarousel() {
  const [offers, setOffers] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ready | error

  // current: index into the CLONED buffer (see buffered below). Starts at 1 = real first item.
  const [current, setCurrent] = useState(1);
  const [isAnimating, setIsAnimating] = useState(true);
  const [isPaused, setIsPaused] = useState(false);

  const timerRef = useRef(null);
  const trackRef = useRef(null);
  const dragStateRef = useRef({ startX: 0, dragging: false });
  const [dragOffset, setDragOffset] = useState(0);

  // ---- Fetch offers.json ----
  useEffect(() => {
    let cancelled = false;

    fetch("/offers.json")
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to load offers (${res.status})`);
        return res.json();
      })
      .then((data) => {
        if (cancelled) return;
        setOffers(Array.isArray(data) ? data : []);
        setStatus("ready");
      })
      .catch((err) => {
        console.error("Failed to fetch offers.json:", err);
        if (!cancelled) setStatus("error");
      });

    return () => {
      cancelled = true;
    };
  }, []);

  // Cloned buffer: [clone of LAST, ...real items, clone of FIRST] — enables the infinite-loop illusion
  const buffered =
    offers.length > 0 ? [offers[offers.length - 1], ...offers, offers[0]] : [];

  const activeDot = offers.length
    ? ((current - 1) + offers.length) % offers.length
    : 0;

  const navigate = useCallback((nextIndex) => {
    setIsAnimating(true);
    setCurrent(nextIndex);
  }, []);

  const goNext = useCallback(() => setCurrent((c) => c + 1), []);
  const goPrev = useCallback(() => setCurrent((c) => c - 1), []);

  useEffect(() => {
    setIsAnimating(true);
  }, [current]);

  // ---- Real transition-end handling (no more guessing with setTimeout) ----
  const handleTransitionEnd = (e) => {
    if (e.target !== trackRef.current) return; // ignore bubbled child transitions
    if (e.propertyName !== "transform") return;

    if (current === buffered.length - 1) {
      // Landed on the clone of FIRST → silently snap to the real first, no animation
      setIsAnimating(false);
      setCurrent(1);
    } else if (current === 0) {
      // Landed on the clone of LAST → silently snap to the real last, no animation
      setIsAnimating(false);
      setCurrent(offers.length);
    }
  };

  // ---- Autoplay: single source of truth, restarts whenever `current` changes or pause toggles ----
  useEffect(() => {
    if (status !== "ready" || isPaused || offers.length === 0) return;

    timerRef.current = setInterval(goNext, AUTOPLAY_DELAY);
    return () => clearInterval(timerRef.current);
  }, [current, isPaused, status, offers.length, goNext]);

  const handlePrev = () => navigate(current - 1);
  const handleNext = () => navigate(current + 1);
  const handleDot = (realIndex) => navigate(realIndex + 1);

  // ---- Keyboard navigation on the whole stage ----
  const handleStageKeyDown = (e) => {
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      handlePrev();
    } else if (e.key === "ArrowRight") {
      e.preventDefault();
      handleNext();
    }
  };

  // ---- Touch / pointer swipe support ----
  const handlePointerDown = (e) => {
    dragStateRef.current = { startX: e.clientX, dragging: true };
    setIsPaused(true);
  };

  const handlePointerMove = (e) => {
    if (!dragStateRef.current.dragging) return;
    setDragOffset(e.clientX - dragStateRef.current.startX);
  };

  const endDrag = () => {
    if (!dragStateRef.current.dragging) return;
    dragStateRef.current.dragging = false;

    if (dragOffset > SWIPE_THRESHOLD_PX) {
      handlePrev();
    } else if (dragOffset < -SWIPE_THRESHOLD_PX) {
      handleNext();
    }
    setDragOffset(0);
    setIsPaused(false);
  };

  // Card width % + gap must match the values used in the translateX calc below
  const CARD_WIDTH_PERCENT = 70;
  const CENTER_OFFSET_PERCENT = (100 - CARD_WIDTH_PERCENT) / 2; // 15%

  const dragOffsetPercent =
    trackRef.current && dragStateRef.current.dragging
      ? (dragOffset / trackRef.current.offsetWidth) * 100
      : 0;

  return (
    <section id="offer" className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl">
        {/* Heading */}
        <h2 className="text-center font-display text-3xl tracking-widest text-white sm:text-4xl">
          WHAT WE OFFER
        </h2>
        <p className="mx-auto mt-4 max-w-md text-center text-sm text-white/60">
          Swipe through the services our team brings to every UNCean production.
        </p>

        {status === "loading" && (
          <p className="mt-16 text-center text-sm text-white/50">Loading services…</p>
        )}

        {status === "error" && (
          <p className="mt-16 text-center text-sm text-red-400">
            Couldn't load our services right now. Please refresh the page.
          </p>
        )}

        {status === "ready" && offers.length > 0 && (
          <div
            className="relative mt-16 overflow-hidden"
            onMouseEnter={() => setIsPaused(true)}
            onMouseLeave={() => setIsPaused(false)}
            onKeyDown={handleStageKeyDown}
            role="region"
            aria-roledescription="carousel"
            aria-label="Our services"
          >
            {/* Screen-reader-only live announcement of the active slide */}
            <p className="sr-only" aria-live="polite">
              Showing {offers[activeDot]?.title}, slide {activeDot + 1} of {offers.length}
            </p>

            {/* Track */}
            <div
              ref={trackRef}
              onTransitionEnd={handleTransitionEnd}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={endDrag}
              onPointerLeave={endDrag}
              className="flex items-center touch-pan-y"
              style={{
                transform: `translateX(calc(-${current * CARD_WIDTH_PERCENT}% + ${CENTER_OFFSET_PERCENT}% + ${dragOffsetPercent}%))`,
                transition:
                  isAnimating && !dragStateRef.current.dragging
                    ? `transform ${TRANSITION_MS}ms cubic-bezier(0.77, 0, 0.18, 1)`
                    : "none",
                gap: "3rem",
                cursor: dragStateRef.current.dragging ? "grabbing" : "grab",
              }}
            >
              {buffered.map((offer, index) => {
                const offset = index - current;
                const isActive = offset === 0;
                const isAdjacent = Math.abs(offset) === 1;

                return (
                  <div
                    key={`${offer.id}-${index}`}
                    tabIndex={isActive ? 0 : -1}
                    role="button"
                    aria-label={`View ${offer.title}`}
                    aria-current={isActive}
                    onClick={() => {
                      if (!isActive) navigate(index);
                    }}
                    onKeyDown={(e) => {
                      if ((e.key === "Enter" || e.key === " ") && !isActive) {
                        e.preventDefault();
                        navigate(index);
                      }
                    }}
                    className="relative shrink-0 overflow-hidden rounded-3xl cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-white"
                    style={{
                      width: `${CARD_WIDTH_PERCENT}%`,
                      aspectRatio: "16 / 9",
                      transform: isActive
                        ? "scale(1)"
                        : isAdjacent
                        ? "scale(0.88)"
                        : "scale(0.80)",
                      opacity: isActive ? 1 : isAdjacent ? 0.45 : 0.2,
                      transition:
                        "transform 750ms cubic-bezier(0.77, 0, 0.18, 1), opacity 750ms ease",
                      filter: isActive ? "none" : "brightness(0.5)",
                    }}
                  >
                    <img
                      src={offer.image}
                      alt={offer.title}
                      loading="lazy"
                      draggable={false}
                      className="h-full w-full select-none object-cover"
                      style={{
                        transition: "transform 750ms cubic-bezier(0.77, 0, 0.18, 1)",
                        transform: isActive ? "scale(1.03)" : "scale(1)",
                      }}
                    />

                    <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                    <div
                      className="absolute inset-x-0 bottom-0 p-6"
                      style={{
                        opacity: isActive ? 1 : 0,
                        transform: isActive ? "translateY(0)" : "translateY(8px)",
                        transition: "opacity 600ms ease, transform 600ms ease",
                      }}
                    >
                      <p className="text-xs font-bold uppercase tracking-[0.25em] text-white/70">
                        Service
                      </p>
                      <p className="mt-1 font-display text-2xl uppercase tracking-wide text-white">
                        {offer.title}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Left arrow */}
            <button
              type="button"
              onClick={handlePrev}
              aria-label="Previous offer"
              className="absolute left-4 top-1/2 z-20 -translate-y-1/2 grid h-12 w-12 place-items-center rounded-full bg-black/40 text-white text-xl backdrop-blur-sm transition-all duration-300 hover:bg-black/70 hover:scale-110 sm:left-6"
            >
              ‹
            </button>

            {/* Right arrow */}
            <button
              type="button"
              onClick={handleNext}
              aria-label="Next offer"
              className="absolute right-4 top-1/2 z-20 -translate-y-1/2 grid h-12 w-12 place-items-center rounded-full bg-black/40 text-white text-xl backdrop-blur-sm transition-all duration-300 hover:bg-black/70 hover:scale-110 sm:right-6"
            >
              ›
            </button>
          </div>
        )}

        {/* Dot indicators */}
        {status === "ready" && offers.length > 0 && (
          <div className="mt-8 flex justify-center gap-2">
            {offers.map((offer, index) => (
              <button
                key={offer.id}
                type="button"
                onClick={() => handleDot(index)}
                aria-label={`Go to ${offer.title}`}
                aria-current={index === activeDot}
                className={`h-2 rounded-full transition-all duration-500 ${
                  index === activeDot ? "w-8 bg-white" : "w-2 bg-white/30 hover:bg-white/50"
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
